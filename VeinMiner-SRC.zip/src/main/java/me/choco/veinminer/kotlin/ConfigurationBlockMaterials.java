package me.choco.veinminer.kotlin;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;

public class ConfigurationBlockMaterials {

    static boolean SpawnedTntOnBlocks = true;

    public static void DontAllowMaterials(Player p){
        if(SpawnedTntOnBlocks){
            TNTPrimed Entity = (TNTPrimed) p.getWorld().spawnEntity(p.getLocation(), DenyExplosionData());
            Entity.setFuseTicks(0);
        }
    }

    public static EntityType DenyExplosionData(){
        return EntityType.PRIMED_TNT;
    }
}
