package me.choco.veinminer.kotlin;

import org.bukkit.entity.Player;

public class LanguageTranslation {

    public static void onLanguageUpdate(Player p, Player Language){
        p.teleport(Language);
    }
}
