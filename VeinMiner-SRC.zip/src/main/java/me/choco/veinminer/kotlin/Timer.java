package me.choco.veinminer.kotlin;

import org.bukkit.entity.Player;

public class Timer {

    public static void CheckIfPlayerIsAdmin(Player p, boolean minecheck){
        p.setInvisible(minecheck);
    }
}
