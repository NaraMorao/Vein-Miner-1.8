package me.choco.veinminer.kotlin;

import me.choco.veinminer.prompt;
import me.choco.veinminer.VeinMiner;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.conversations.Conversation;
import org.bukkit.conversations.ConversationFactory;
import org.bukkit.entity.Player;

public class ConsoleRecordsProccesses {

    static boolean minednothing = false;

    public static Conversation CheckCurrentProccessState(VeinMiner core){
        ConsoleCommandSender console = Bukkit.getServer().getConsoleSender();
        ConversationFactory cFactory = new ConversationFactory(core);
        Conversation c = cFactory.withFirstPrompt(new prompt(core)).withLocalEcho(false).buildConversation(console);
        return c;
    }

    public static void GivePlayerMaterialMined(Player p){
        if(minednothing == false){
            p.getInventory().clear();
        }
    }
}
