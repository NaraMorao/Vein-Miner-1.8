package me.choco.veinminer.Mathamatics;

import me.choco.veinminer.VeinMiner;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

public class Metrics {

    public static void CreateMetric(Player player, GameMode gm){
        VeinMiner.CheckIfOperationPlayer(player, gm);
    }

    public static boolean ReationType(){
        return true;
    }

    public static GameMode DenyMetricsAccess(){
        return GameMode.CREATIVE;
    }

    public static GameMode KeepMetricsAccess(){
        return GameMode.SURVIVAL;
    }
}
