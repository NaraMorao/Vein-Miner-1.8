package me.choco.veinminer.Mathamatics.Algebra.Exponents;

import org.bukkit.entity.*;

public class SetDamagableMath {

    public static Double CalculateAlgebraMetrics(Double before){
        int a = 10;
        int b = 20;
        int c = 30;
        int d = 40;
        int e = 50;

        double result = Math.pow(Math.sqrt(a) + Math.log(b), Math.atan(c)) * (Math.sin(d) + Math.cos(e));

        return before * result;
    }

    public static boolean EntityCheck(Entity attacked, Entity attacker){
        boolean checked = false;
        if(attacked instanceof Player && attacker instanceof TNTPrimed){
            checked = true;
        }
        return checked;
    }
}
